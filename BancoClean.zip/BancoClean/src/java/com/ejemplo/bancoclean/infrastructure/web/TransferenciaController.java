package java.com.ejemplo.bancoclean.infrastructure.web;

import java.com.ejemplo.bancoclean.domain.service.TransferenciaService;

public class TransferenciaController {

    private TransferenciaService transferenciaService;
    // Constructor y métodos del controlador
}
