package java.com.ejemplo.bancoclean.infrastructure.persistence;

import java.com.ejemplo.bancoclean.domain.model.Usuario;
import java.com.ejemplo.bancoclean.domain.repository.UsuarioRepository;

public class UsuarioRepositoryImpl implements UsuarioRepository {
    @Override
    public Usuario findById(String id) {
        return null;
    }

    @Override
    public void save(Usuario usuario) {

    }

    @Override
    public void deleteById(String id) {

    }
}
