package java.com.ejemplo.bancoclean.domain.model;

public class Usuario {

    private String id;
    private String nombre;
    private String apellido;

    // Constructor, getters y setters
}
