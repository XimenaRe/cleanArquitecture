package java.com.ejemplo.bancoclean.domain.service;

import java.com.ejemplo.bancoclean.domain.repository.CuentaRepository;
import java.com.ejemplo.bancoclean.domain.repository.UsuarioRepository;

public class TransferenciaService {
    private UsuarioRepository usuarioRepository;
    private CuentaRepository cuentaRepository;

    // Constructor y métodos del servicio
}
