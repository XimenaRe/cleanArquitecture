package java.com.ejemplo.bancoclean.domain.model;

public class Cuenta {

    private String id;
    private int saldo;
}
